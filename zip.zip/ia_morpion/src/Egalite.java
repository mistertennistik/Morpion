
/**
 * Classe représentant une situation de jeu où la partie est terminée et où il n'y aucun vainqueur
 */
public class Egalite implements Situation {
	// Rien
}
