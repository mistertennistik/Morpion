
/**
 * Classe représentant la situation de jeu où la partie n'est pas encore terminée
 */
public class EnCours implements Situation {

}
