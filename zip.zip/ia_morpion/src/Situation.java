
/**
 * Interface représentant une situation de jeu
 */
public interface Situation {

}
